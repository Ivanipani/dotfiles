return {
    "benomahony/uv.nvim",
    opts = {
        picker_integration = true,
    }
}
